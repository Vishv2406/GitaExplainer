"use client"

import { useState } from "react"
import { ChevronDown, Sparkles, Lightbulb, Heart, BookOpen } from "lucide-react"
import { cn } from "@/lib/utils"

type ExplanationType = "simple" | "example" | "philosophical"

const explanationIcons = {
  simple: Lightbulb,
  example: Heart,
  philosophical: BookOpen,
}

const explanationDescriptions = {
  simple: "This verse teaches us that our right is to action alone, not to its fruits. We should perform our duties without attachment to results, finding fulfillment in the act itself rather than its outcomes.",
  example: "Imagine a student studying for an exam. Instead of being anxious about grades, they focus entirely on learning and understanding. This approach reduces stress and often leads to better results naturally.",
  philosophical: "This teaching represents the core of Nishkama Karma - selfless action. It connects to the broader Vedantic philosophy that liberation comes through detachment from ego-driven desires while still engaging fully with life's responsibilities.",
}

export function AIExplanation() {
  const [isOpen, setIsOpen] = useState(false)
  const [activeType, setActiveType] = useState<ExplanationType | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  const explanationTypes = [
    { id: "simple" as const, label: "Simple Meaning", icon: Lightbulb },
    { id: "example" as const, label: "Life Example", icon: Heart },
    { id: "philosophical" as const, label: "Philosophical Insight", icon: BookOpen },
  ]

  const handleTypeClick = (type: ExplanationType) => {
    if (activeType === type) return
    setIsLoading(true)
    setActiveType(type)
    // Simulate AI loading
    setTimeout(() => setIsLoading(false), 600)
  }

  return (
    <div className="border border-border/30 rounded-xl overflow-hidden bg-gradient-to-b from-card/80 to-card/40 backdrop-blur-sm">
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between p-5 text-left hover:bg-card/60 transition-colors duration-300"
        aria-expanded={isOpen}
      >
        <span className="flex items-center gap-3 font-sans text-sm font-medium text-foreground">
          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
            <Sparkles className="h-4 w-4 text-primary" />
          </div>
          Understand this Shlok
        </span>
        <ChevronDown
          className={cn(
            "h-4 w-4 text-muted-foreground transition-transform duration-300",
            isOpen && "rotate-180"
          )}
        />
      </button>

      <div
        className={cn(
          "overflow-hidden transition-all duration-500 ease-out",
          isOpen ? "max-h-[500px] opacity-100" : "max-h-0 opacity-0"
        )}
      >
        <div className="px-5 pb-5 space-y-5">
          {/* Mode buttons */}
          <div className="flex flex-wrap gap-2">
            {explanationTypes.map((type) => {
              const Icon = type.icon
              return (
                <button
                  key={type.id}
                  type="button"
                  onClick={() => handleTypeClick(type.id)}
                  className={cn(
                    "group flex items-center gap-2 px-4 py-2.5 text-xs font-sans rounded-full border transition-all duration-300",
                    activeType === type.id
                      ? "bg-primary text-primary-foreground border-primary shadow-lg shadow-primary/20"
                      : "bg-card/60 border-border/40 text-muted-foreground hover:border-primary/40 hover:text-foreground hover:bg-card"
                  )}
                >
                  <Icon className={cn(
                    "h-3.5 w-3.5 transition-transform duration-300",
                    activeType === type.id ? "scale-110" : "group-hover:scale-110"
                  )} />
                  {type.label}
                </button>
              )
            })}
          </div>

          {/* Response area */}
          <div className="relative min-h-32 p-5 rounded-lg bg-background/60 border border-border/20">
            {isLoading ? (
              <div className="flex items-center justify-center h-24">
                <div className="flex gap-1">
                  <div className="w-2 h-2 rounded-full bg-primary/60 animate-bounce" style={{ animationDelay: "0ms" }} />
                  <div className="w-2 h-2 rounded-full bg-primary/60 animate-bounce" style={{ animationDelay: "150ms" }} />
                  <div className="w-2 h-2 rounded-full bg-primary/60 animate-bounce" style={{ animationDelay: "300ms" }} />
                </div>
              </div>
            ) : activeType ? (
              <div className="space-y-3 animate-in fade-in duration-500">
                <div className="flex items-center gap-2 text-xs text-primary/70 uppercase tracking-wider">
                  {(() => {
                    const Icon = explanationIcons[activeType]
                    return <Icon className="h-3.5 w-3.5" />
                  })()}
                  {explanationTypes.find(t => t.id === activeType)?.label}
                </div>
                <p className="text-sm text-foreground/90 leading-relaxed">
                  {explanationDescriptions[activeType]}
                </p>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-24 text-center">
                <Sparkles className="h-5 w-5 text-primary/40 mb-2" />
                <p className="text-sm text-muted-foreground/60">
                  Select a mode above for AI-powered insights
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
