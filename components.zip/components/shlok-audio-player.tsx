"use client"

import { useRef, useState } from "react"
import { Play, Pause } from "lucide-react"

interface Props {
  chapter: number
  shlok: number
}

export function ShlokAudioPlayer({ chapter, shlok }: Props) {
  const [mode, setMode] = useState<"sanskrit" | "hindi" | "english">("sanskrit")
  const [playing, setPlaying] = useState(false)

  const audioRef = useRef<HTMLAudioElement>(null)

  const basePath = `/audio/CHAP${chapter}/${String(shlok).padStart(2, "0")}`

  const getSrc = () => {
    if (mode === "sanskrit") return `${basePath}-mool_sloka.ogg`
    if (mode === "hindi") return `${basePath}-hindi_translation.ogg`
    return `${basePath}-english_translations.ogg`
  }

  const togglePlay = () => {
    const audio = audioRef.current
    if (!audio) return

    if (playing) {
      audio.pause()
      setPlaying(false)
    } else {
      audio.play()
      setPlaying(true)
    }
  }

  return (
    <div className="flex flex-col items-center gap-4">
      <audio
        ref={audioRef}
        src={getSrc()}
        onEnded={() => setPlaying(false)}
      />

      {/* Main play button */}
      <button
        onClick={togglePlay}
        className="w-14 h-14 rounded-full bg-primary/20 flex items-center justify-center hover:bg-primary/30 transition"
      >
        {playing ? (
          <Pause className="w-6 h-6" />
        ) : (
          <Play className="w-6 h-6" />
        )}
      </button>

      {/* Mode buttons */}
      <div className="flex gap-2 text-xs">
        <button
          onClick={() => setMode("sanskrit")}
          className={`px-3 py-1 rounded-full ${
            mode === "sanskrit" ? "bg-primary text-white" : "bg-card"
          }`}
        >
          Sanskrit
        </button>

        <button
          onClick={() => setMode("hindi")}
          className={`px-3 py-1 rounded-full ${
            mode === "hindi" ? "bg-primary text-white" : "bg-card"
          }`}
        >
          Hindi
        </button>

        <button
          onClick={() => setMode("english")}
          className={`px-3 py-1 rounded-full ${
            mode === "english" ? "bg-primary text-white" : "bg-card"
          }`}
        >
          English
        </button>
      </div>
    </div>
  )
}
